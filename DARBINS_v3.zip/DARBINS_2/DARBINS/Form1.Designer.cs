﻿namespace DARBINS
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.izvele_2 = new System.Windows.Forms.CheckBox();
            this.izvele_1 = new System.Windows.Forms.CheckBox();
            this.label8 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.Indeks = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.DatoraPunkti = new System.Windows.Forms.TextBox();
            this.SpeletejaPunkti = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Result = new System.Windows.Forms.TextBox();
            this.SkaitluVirkne = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Minimax = new System.Windows.Forms.CheckBox();
            this.Alfa_Beta = new System.Windows.Forms.CheckBox();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.Alfa_Beta);
            this.panel1.Controls.Add(this.Minimax);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.izvele_2);
            this.panel1.Controls.Add(this.izvele_1);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.Indeks);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.DatoraPunkti);
            this.panel1.Controls.Add(this.SpeletejaPunkti);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.Result);
            this.panel1.Controls.Add(this.SkaitluVirkne);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(27, 28);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1171, 624);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(56, 65);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(1108, 180);
            this.label9.TabIndex = 24;
            this.label9.Text = resources.GetString("label9.Text");
            // 
            // izvele_2
            // 
            this.izvele_2.AutoSize = true;
            this.izvele_2.Location = new System.Drawing.Point(350, 556);
            this.izvele_2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.izvele_2.Name = "izvele_2";
            this.izvele_2.Size = new System.Drawing.Size(83, 24);
            this.izvele_2.TabIndex = 23;
            this.izvele_2.Text = "Dators";
            this.izvele_2.UseVisualStyleBackColor = true;
            // 
            // izvele_1
            // 
            this.izvele_1.AutoSize = true;
            this.izvele_1.Location = new System.Drawing.Point(350, 518);
            this.izvele_1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.izvele_1.Name = "izvele_1";
            this.izvele_1.Size = new System.Drawing.Size(84, 24);
            this.izvele_1.TabIndex = 22;
            this.izvele_1.Text = "Cilvēks";
            this.izvele_1.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(346, 481);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(177, 20);
            this.label8.TabIndex = 21;
            this.label8.Text = "Izvēlies kurš uzsāk spēli";
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.button4.Location = new System.Drawing.Point(982, 518);
            this.button4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(117, 62);
            this.button4.TabIndex = 20;
            this.button4.Text = "&RESTART";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.RESTART);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.button3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button3.Location = new System.Drawing.Point(844, 518);
            this.button3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(101, 62);
            this.button3.TabIndex = 19;
            this.button3.Text = "&EXIT";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.Exit);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.button2.Location = new System.Drawing.Point(844, 335);
            this.button2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(101, 62);
            this.button2.TabIndex = 18;
            this.button2.Text = "&ENTER";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.ENTER);
            // 
            // button1
            // 
            this.button1.Enabled = false;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.button1.Location = new System.Drawing.Point(844, 404);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(101, 62);
            this.button1.TabIndex = 17;
            this.button1.Text = "&Spēlētāja gājiens";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.CHANGE);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.label7.Location = new System.Drawing.Point(28, 18);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(143, 20);
            this.label7.TabIndex = 16;
            this.label7.Text = "Spēles apraksts:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.label11.Location = new System.Drawing.Point(28, 42);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(0, 20);
            this.label11.TabIndex = 15;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(52, 72);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(0, 20);
            this.label10.TabIndex = 14;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(44, 162);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(0, 20);
            this.label6.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(28, 394);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(527, 20);
            this.label5.TabIndex = 9;
            this.label5.Text = "Ievadi skaitļu pāru indeksu virknē, kurus vēlies mainīt ( ar \";\" atdali skaitļus)" +
    "";
            // 
            // Indeks
            // 
            this.Indeks.Location = new System.Drawing.Point(576, 391);
            this.Indeks.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Indeks.Name = "Indeks";
            this.Indeks.Size = new System.Drawing.Size(222, 26);
            this.Indeks.TabIndex = 8;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.label4.Location = new System.Drawing.Point(28, 538);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(118, 20);
            this.label4.TabIndex = 7;
            this.label4.Text = "Datora punkti";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.label3.Location = new System.Drawing.Point(32, 484);
            this.label3.Name = "label3";
            this.label3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label3.Size = new System.Drawing.Size(139, 20);
            this.label3.TabIndex = 6;
            this.label3.Text = "Spēlētāja punkti";
            // 
            // DatoraPunkti
            // 
            this.DatoraPunkti.Location = new System.Drawing.Point(177, 535);
            this.DatoraPunkti.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.DatoraPunkti.Name = "DatoraPunkti";
            this.DatoraPunkti.ReadOnly = true;
            this.DatoraPunkti.Size = new System.Drawing.Size(100, 26);
            this.DatoraPunkti.TabIndex = 5;
            // 
            // SpeletejaPunkti
            // 
            this.SpeletejaPunkti.Location = new System.Drawing.Point(177, 481);
            this.SpeletejaPunkti.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.SpeletejaPunkti.Name = "SpeletejaPunkti";
            this.SpeletejaPunkti.ReadOnly = true;
            this.SpeletejaPunkti.Size = new System.Drawing.Size(100, 26);
            this.SpeletejaPunkti.TabIndex = 4;
            this.SpeletejaPunkti.TextChanged += new System.EventHandler(this.SpeletejaPunkti_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.label2.Location = new System.Drawing.Point(484, 444);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 20);
            this.label2.TabIndex = 3;
            this.label2.Text = "Rezultāts";
            // 
            // Result
            // 
            this.Result.Location = new System.Drawing.Point(576, 441);
            this.Result.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Result.Name = "Result";
            this.Result.ReadOnly = true;
            this.Result.Size = new System.Drawing.Size(222, 26);
            this.Result.TabIndex = 2;
            // 
            // SkaitluVirkne
            // 
            this.SkaitluVirkne.Location = new System.Drawing.Point(522, 356);
            this.SkaitluVirkne.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.SkaitluVirkne.Name = "SkaitluVirkne";
            this.SkaitluVirkne.Size = new System.Drawing.Size(222, 26);
            this.SkaitluVirkne.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(28, 356);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(461, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ievadiet skaitļu virknes garumu diapazonā no 15 līdz 25 skaitļiem";
            // 
            // Minimax
            // 
            this.Minimax.AutoSize = true;
            this.Minimax.Location = new System.Drawing.Point(440, 538);
            this.Minimax.Name = "Minimax";
            this.Minimax.Size = new System.Drawing.Size(178, 24);
            this.Minimax.TabIndex = 25;
            this.Minimax.Text = "Minimaksa algoritms";
            this.Minimax.UseVisualStyleBackColor = true;
            // 
            // Alfa_Beta
            // 
            this.Alfa_Beta.AutoSize = true;
            this.Alfa_Beta.Location = new System.Drawing.Point(440, 569);
            this.Alfa_Beta.Name = "Alfa_Beta";
            this.Alfa_Beta.Size = new System.Drawing.Size(168, 24);
            this.Alfa_Beta.TabIndex = 26;
            this.Alfa_Beta.Text = "Alfa-beta algoritms";
            this.Alfa_Beta.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1210, 662);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox SkaitluVirkne;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Result;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox DatoraPunkti;
        private System.Windows.Forms.TextBox SpeletejaPunkti;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox Indeks;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.CheckBox izvele_1;
        private System.Windows.Forms.CheckBox izvele_2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.CheckBox Alfa_Beta;
        private System.Windows.Forms.CheckBox Minimax;
    }
}

